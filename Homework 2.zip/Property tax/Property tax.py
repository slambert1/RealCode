def main():
    property_value = int(input("Enter the property's actual value: "))
    calc_assessment_tax(property_value)

def calc_assessment_tax(property_value):
    assessment_value = property_value * 0.6
    print('The assessment value is:', format(assessment_value, '.2f'))
    calc_assessment_tax = assessment_value * 0.0072
    print('The property tax is:', format(calc_assessment_tax, '.2f'))
main()