starting = int(input("Starting number of organisms: "))
increase = float(input("Enter the average daily increase: "))/100.0
days = int(input("Number of days to multiply: "))
day_1 = True
print("Day Approximate\tPopulation")

for days in range(starting, days+ 1):
    if day_1:
        print(1, '\t', starting)
        day_1 = False
    add = starting * increase
    starting= starting + add
    print(days, '\t', starting)
