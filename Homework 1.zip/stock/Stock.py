Number_shares = 2000
Purchase_price = 40.00
Selling_price = 42.75
Commission_rate =0.03

total_before_commission = (Number_shares * Purchase_price)
broker_commission = (total_before_commission * Commission_rate)/100
total_of_purchase = (broker_commission + total_before_commission)

print("Amount of money Joe paid for stock: $",format(total_before_commission,'.2f'))
print("Amount of commission Joe paid his broker when buying stock: $",format(broker_commission,',.2f'))

sold_shares = (Number_shares * Selling_price)
Commission_after_sale = (sold_shares * Commission_rate)/100

print("Amount of money Joe sold the stock for: $",format(sold_shares,',.2f'))
print("Amount of commission Joe paid his broker when he sold the stock: $",format(Commission_after_sale,',.2f'))

Money_left_over = (sold_shares - Commission_after_sale)
print("Amount of money Joe had left when he sold the stock and paid his broker: $",format(Money_left_over,',.2f'))

if Money_left_over > 0:
    print("Joe made a profit!")
else:
    print("Joe lost Money")
